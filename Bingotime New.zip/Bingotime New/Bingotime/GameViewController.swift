
import UIKit

class GameViewController: UIViewController {
    
    var showName:String = ""
    //var randomExerciseIndex1 : Int = 0
    
    var randomExerciseIndex1: Int = 0

    @IBOutlet var nameLabel: UILabel!
    
    
    @IBAction func newGameUpdateButtonImages(_ sender: UIButton) {
        randomExerciseIndex1 = Int(arc4random_uniform(4))
        //let exerciseImageArray = ["cruches","jogging","situps","skipping"] //randomize by numbers not by actual name
        let exerciseImageArray = ["exercise1","exercise2","exercise3","exercise4"]
        
        //        sender.setImage(UIImage(named: exerciseImageArray[randomExerciseIndex1]))
        //        button1.image = UIImage(named: exerciseImageArray[randomExerciseIndex1])
        button1.setImage(UIImage(named: exerciseImageArray[randomExerciseIndex1]), for: .normal)
        button2.setImage(UIImage(named: exerciseImageArray[randomExerciseIndex1]), for: .normal)

    }
    

    


    
    override func viewDidLoad() {
        super.viewDidLoad()

        nameLabel.text! = showName
    }
    
//    func updateImagesAndNewGame(){
//        randomExerciseIndex1 = Int(arc4random_uniform(4))
//        let exerciseImageArray = ["cruches","jogging","situps","skipping"]
//        button1.image = UIImage(named: exerciseImageArray[randomExerciseIndex1])
//    }

    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button4: UIButton!
    @IBOutlet weak var button5: UIButton!
    @IBOutlet weak var button6: UIButton!
    @IBOutlet weak var button7: UIButton!
    @IBOutlet weak var button8: UIButton!
    @IBOutlet weak var button9: UIButton!
    @IBOutlet weak var button10: UIButton!
    @IBOutlet weak var button11: UIButton!
    @IBOutlet weak var button12: UIButton!
    @IBOutlet weak var button13: UIButton!
    @IBOutlet weak var button14: UIButton!
    @IBOutlet weak var button15: UIButton!
    @IBOutlet weak var button16: UIButton!
    @IBOutlet weak var button17: UIButton!
    @IBOutlet weak var button18: UIButton!
    @IBOutlet weak var button19: UIButton!
    @IBOutlet weak var button20: UIButton!
    @IBOutlet weak var button21: UIButton!
    @IBOutlet weak var button22: UIButton!
    @IBOutlet weak var button23: UIButton!
    @IBOutlet weak var button24: UIButton!
    @IBOutlet weak var button25: UIButton!
    
    
    //all 25 buttons linked to 1 function dynamically
    @IBAction func buttonClickedImage(_ sender: UIButton) {
        //        if(sender.tag == 0 && button1.isSelected == false){
        //            self.button1.layer.borderWidth = 2.0
        //            self.button1.layer.borderColor = UIColor.purple.cgColor
        //        }
        
        //        else if (button1.isSelected){
        //            self.button1.layer.borderWidth = 2.0
        //            self.button1.layer.borderColor = UIColor.red.cgColor
        //        }
        
        if sender.tag == 1{
            self.button1.layer.borderWidth = 2.0
            self.button1.layer.borderColor = UIColor.blue.cgColor
        }
        if(sender.tag == 2){
            self.button2.layer.borderWidth = 2.0
            self.button2.layer.borderColor = UIColor.blue.cgColor
        }
        if(sender.tag == 3){
            self.button3.layer.borderWidth = 2.0
            self.button3.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 1{
            self.button1.layer.borderWidth = 2.0
            self.button1.layer.borderColor = UIColor.blue.cgColor
        }
        if(sender.tag == 2){
            self.button2.layer.borderWidth = 2.0
            self.button2.layer.borderColor = UIColor.blue.cgColor
        }
        if(sender.tag == 3){
            self.button3.layer.borderWidth = 2.0
            self.button3.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 4{
            self.button4.layer.borderWidth = 2.0
            self.button4.layer.borderColor = UIColor.blue.cgColor
        }
        if(sender.tag == 5){
            self.button5.layer.borderWidth = 2.0
            self.button5.layer.borderColor = UIColor.blue.cgColor
        }
        if(sender.tag == 6){
            self.button6.layer.borderWidth = 2.0
            self.button6.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 7{
            self.button7.layer.borderWidth = 2.0
            self.button7.layer.borderColor = UIColor.blue.cgColor
        }
        if(sender.tag == 8){
            self.button8.layer.borderWidth = 2.0
            self.button8.layer.borderColor = UIColor.blue.cgColor
        }
        if(sender.tag == 9){
            self.button9.layer.borderWidth = 2.0
            self.button9.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 10{
            self.button10.layer.borderWidth = 2.0
            self.button10.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 11{
            self.button11.layer.borderWidth = 2.0
            self.button11.layer.borderColor = UIColor.blue.cgColor
        }
        if(sender.tag == 12){
            self.button12.layer.borderWidth = 2.0
            self.button12.layer.borderColor = UIColor.blue.cgColor
        }
        if(sender.tag == 13){
            self.button13.layer.borderWidth = 2.0
            self.button13.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 14{
            self.button14.layer.borderWidth = 2.0
            self.button14.layer.borderColor = UIColor.blue.cgColor
        }
        if(sender.tag == 15){
            self.button15.layer.borderWidth = 2.0
            self.button15.layer.borderColor = UIColor.blue.cgColor
        }
        if(sender.tag == 16){
            self.button16.layer.borderWidth = 2.0
            self.button16.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 17{
            self.button17.layer.borderWidth = 2.0
            self.button17.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 18{
            self.button18.layer.borderWidth = 2.0
            self.button18.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 19{
            self.button19.layer.borderWidth = 2.0
            self.button19.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 20{
            self.button20.layer.borderWidth = 2.0
            self.button20.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 21{
            self.button1.layer.borderWidth = 2.0
            self.button1.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 22{
            self.button22.layer.borderWidth = 2.0
            self.button22.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 23{
            self.button23.layer.borderWidth = 2.0
            self.button23.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 24{
            self.button24.layer.borderWidth = 2.0
            self.button24.layer.borderColor = UIColor.blue.cgColor
        }
        if sender.tag == 25{
            self.button25.layer.borderWidth = 2.0
            self.button25.layer.borderColor = UIColor.blue.cgColor
        }
        
    }
    
    
 

}
