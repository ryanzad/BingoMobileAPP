
import UIKit

class ViewController: UIViewController {
    @IBOutlet var userName: UITextField!
    var capitalisedName:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func buttonPress(_ sender: Any) {
        performSegue(withIdentifier: "goGame", sender: self)
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goGame"{
            let nextVC = segue.destination as! GameViewController
            nextVC.showName = userName.text!
        }
    }
    

}

