
import UIKit

class GameViewController: UIViewController {
    
    var showName:String = ""
    var randomExerciseIndex1 : Int = 0
    var randomExerciseIndex2 : Int = 0
    var randomExerciseIndex3 : Int = 0
    var randomExerciseIndex4 : Int = 0
    var randomExerciseIndex5 : Int = 0
    var randomExerciseIndex6 : Int = 0
    var randomExerciseIndex7 : Int = 0
    var randomExerciseIndex8 : Int = 0
    var randomExerciseIndex9 : Int = 0
    var randomExerciseIndex10 : Int = 0
    var randomExerciseIndex11 : Int = 0
    var randomExerciseIndex12 : Int = 0
    var randomExerciseIndex13 : Int = 0
    var randomExerciseIndex14 : Int = 0
    var randomExerciseIndex15 : Int = 0
    var randomExerciseIndex16 : Int = 0
    var randomExerciseIndex17 : Int = 0
    var randomExerciseIndex18 : Int = 0
    var randomExerciseIndex19 : Int = 0
    var randomExerciseIndex20 : Int = 0
    var randomExerciseIndex21 : Int = 0
    var randomExerciseIndex22 : Int = 0
    var randomExerciseIndex23 : Int = 0
    var randomExerciseIndex24 : Int = 0
    var randomExerciseIndex25 : Int = 0
    
    var randomImgViewIndex: Int = 0
    
    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var img3: UIImageView!
    @IBOutlet weak var img4: UIImageView!
    @IBOutlet weak var img5: UIImageView!
    @IBOutlet weak var img6: UIImageView!
    @IBOutlet weak var img7: UIImageView!
    @IBOutlet weak var img8: UIImageView!
    @IBOutlet weak var img9: UIImageView!
    @IBOutlet weak var img10: UIImageView!
    @IBOutlet weak var img11: UIImageView!
    @IBOutlet weak var img12: UIImageView!
    @IBOutlet weak var img13: UIImageView!
    @IBOutlet weak var img14: UIImageView!
    @IBOutlet weak var img15: UIImageView!
    @IBOutlet weak var img16: UIImageView!
    @IBOutlet weak var img17: UIImageView!
    @IBOutlet weak var img18: UIImageView!
    @IBOutlet weak var img19: UIImageView!
    @IBOutlet weak var img20: UIImageView!
    @IBOutlet weak var img21: UIImageView!
    @IBOutlet weak var img22: UIImageView!
    @IBOutlet weak var img23: UIImageView!
    @IBOutlet weak var img24: UIImageView!
    @IBOutlet weak var img25: UIImageView!
    
    
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet weak var playBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        nameLabel.text! = showName
    }
    
    @IBAction func playButton(_ sender: Any) {
        updateExerciseImages()
    }
    
    func updateExerciseImages(){
        randomImgViewIndex = Int(arc4random_uniform(25))
        
        randomExerciseIndex1 = Int(arc4random_uniform(4))
        randomExerciseIndex2 = Int(arc4random_uniform(4))
        randomExerciseIndex3 = Int(arc4random_uniform(4))
        randomExerciseIndex4 = Int(arc4random_uniform(4))
        randomExerciseIndex5 = Int(arc4random_uniform(4))
        randomExerciseIndex6 = Int(arc4random_uniform(4))
        randomExerciseIndex7 = Int(arc4random_uniform(4))
        randomExerciseIndex8 = Int(arc4random_uniform(4))
        randomExerciseIndex9 = Int(arc4random_uniform(4))
        randomExerciseIndex10 = Int(arc4random_uniform(4))
        randomExerciseIndex11 = Int(arc4random_uniform(4))
        randomExerciseIndex12 = Int(arc4random_uniform(4))
        randomExerciseIndex13 = Int(arc4random_uniform(4))
        randomExerciseIndex14 = Int(arc4random_uniform(4))
        randomExerciseIndex15 = Int(arc4random_uniform(4))
        randomExerciseIndex16 = Int(arc4random_uniform(4))
        randomExerciseIndex17 = Int(arc4random_uniform(4))
        randomExerciseIndex18 = Int(arc4random_uniform(4))
        randomExerciseIndex19 = Int(arc4random_uniform(4))
        randomExerciseIndex20 = Int(arc4random_uniform(4))
        randomExerciseIndex21 = Int(arc4random_uniform(4))
        randomExerciseIndex22 = Int(arc4random_uniform(4))
        randomExerciseIndex23 = Int(arc4random_uniform(4))
        randomExerciseIndex24 = Int(arc4random_uniform(4))
        randomExerciseIndex25 = Int(arc4random_uniform(4))
        
        //exercise array of all images in array
        let imagesArray = ["crunches","jogging","situps","skipping"]
        
        //let numberRandomExImgIndex = Int.random(in: 0...4)
        //let numberRandomImgViewIndex = Int.random(in: 0...25)
        
        //img[randomExerciseIndex].image = UIImage(named: imagesArray[randomExerciseIndex])
        img1.image = UIImage(named: imagesArray[randomExerciseIndex1])
        img2.image = UIImage(named: imagesArray[randomExerciseIndex2])
        img3.image = UIImage(named: imagesArray[randomExerciseIndex3])
        img4.image = UIImage(named: imagesArray[randomExerciseIndex4])
        img5.image = UIImage(named: imagesArray[randomExerciseIndex5])
        img6.image = UIImage(named: imagesArray[randomExerciseIndex6])
        img7.image = UIImage(named: imagesArray[randomExerciseIndex7])
        img8.image = UIImage(named: imagesArray[randomExerciseIndex8])
        img9.image = UIImage(named: imagesArray[randomExerciseIndex9])
        img10.image = UIImage(named: imagesArray[randomExerciseIndex10])
        img11.image = UIImage(named: imagesArray[randomExerciseIndex11])
        img12.image = UIImage(named: imagesArray[randomExerciseIndex12])
        img13.image = UIImage(named: imagesArray[randomExerciseIndex13])
        img14.image = UIImage(named: imagesArray[randomExerciseIndex14])
        img15.image = UIImage(named: imagesArray[randomExerciseIndex15])
        img16.image = UIImage(named: imagesArray[randomExerciseIndex16])
        img17.image = UIImage(named: imagesArray[randomExerciseIndex17])
        img18.image = UIImage(named: imagesArray[randomExerciseIndex18])
        img19.image = UIImage(named: imagesArray[randomExerciseIndex19])
        img20.image = UIImage(named: imagesArray[randomExerciseIndex20])
        img21.image = UIImage(named: imagesArray[randomExerciseIndex21])
        img22.image = UIImage(named: imagesArray[randomExerciseIndex22])
        img23.image = UIImage(named: imagesArray[randomExerciseIndex23])
        img24.image = UIImage(named: imagesArray[randomExerciseIndex24])
        img25.image = UIImage(named: imagesArray[randomExerciseIndex25])

        
    }
    
}
